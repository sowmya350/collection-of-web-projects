// Auth System with LocalStorage and Callbacks
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const loginBtn = document.getElementById('login-btn');
    const signupBtn = document.getElementById('signup-btn');
    const showSignup = document.getElementById('show-signup');
    const showLogin = document.getElementById('show-login');
    const loginMessage = document.getElementById('login-message');
    const signupMessage = document.getElementById('signup-message');

    // Toggle between forms
    showSignup.addEventListener('click', function() {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
        clearMessages();
    });

    showLogin.addEventListener('click', function() {
        signupForm.style.display = 'none';
        loginForm.style.display = 'block';
        clearMessages();
    });

    function clearMessages() {
        loginMessage.textContent = '';
        signupMessage.textContent = '';
        loginMessage.className = 'error';
        signupMessage.className = 'error';
    }

    // Auth Functions with Callbacks
    const auth = {
        // Sign up a new user
        signup: function(username, password, confirmPassword, callback) {
            // Validate inputs
            if (password !== confirmPassword) {
                return callback(new Error('Passwords do not match'));
            }
            
            if (password.length < 6) {
                return callback(new Error('Password must be at least 6 characters'));
            }
            
            // Check if user already exists
            this.getUser(username, function(err, user) {
                if (user) {
                    return callback(new Error('Username already exists'));
                }
                
                // Create new user
                const users = JSON.parse(localStorage.getItem('users') || '{}');
                users[username] = { username, password };
                localStorage.setItem('users', JSON.stringify(users));
                
                callback(null, { username });
            });
        },
        
        // Login an existing user
        login: function(username, password, callback) {
            this.getUser(username, function(err, user) {
                if (err || !user) {
                    return callback(new Error('User not found'));
                }
                
                if (user.password !== password) {
                    return callback(new Error('Incorrect password'));
                }
                
                // Set current user in localStorage
                localStorage.setItem('currentUser', JSON.stringify(user));
                
                callback(null, user);
            });
        },
        
        // Get user from storage
        getUser: function(username, callback) {
            const users = JSON.parse(localStorage.getItem('users') || '{}');
            const user = users[username];
            
            // Simulate async operation with setTimeout
            setTimeout(function() {
                callback(null, user);
            }, 0);
        },
        
        // Get current logged in user
        getCurrentUser: function() {
            const user = localStorage.getItem('currentUser');
            return user ? JSON.parse(user) : null;
        },
        
        // Logout current user
        logout: function() {
            localStorage.removeItem('currentUser');
        }
    };

    // Event Listeners
    loginBtn.addEventListener('click', function(e) {
        e.preventDefault();
        const username = document.getElementById('login-username').value;
        const password = document.getElementById('login-password').value;
        
        auth.login(username, password, function(err, user) {
            if (err) {
                loginMessage.textContent = err.message;
                loginMessage.className = 'error';
            } else {
                loginMessage.textContent = `Welcome, ${user.username}! Login successful.`;
                loginMessage.className = 'success';
                // Redirect or do something after successful login
            }
        });
    });

    signupBtn.addEventListener('click', function(e) {
        e.preventDefault();
        const username = document.getElementById('signup-username').value;
        const password = document.getElementById('signup-password').value;
        const confirmPassword = document.getElementById('signup-confirm-password').value;
        
        auth.signup(username, password, confirmPassword, function(err, user) {
            if (err) {
                signupMessage.textContent = err.message;
                signupMessage.className = 'error';
            } else {
                signupMessage.textContent = `Account created for ${user.username}! You can now login.`;
                signupMessage.className = 'success';
                
                // Clear form
                document.getElementById('signup-username').value = '';
                document.getElementById('signup-password').value = '';
                document.getElementById('signup-confirm-password').value = '';
                
                // Show login form after delay
                setTimeout(function() {
                    signupForm.style.display = 'none';
                    loginForm.style.display = 'block';
                    signupMessage.textContent = '';
                }, 2000);
            }
        });
    });

    // Check if user is already logged in
    const currentUser = auth.getCurrentUser();
    if (currentUser) {
        loginMessage.textContent = `Welcome back, ${currentUser.username}! You are already logged in.`;
        loginMessage.className = 'success';
    }
});