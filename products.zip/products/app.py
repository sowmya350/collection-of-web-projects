from flask import Flask, request, jsonify
from flask_mysqldb import MySQL
from flask_bcrypt import Bcrypt
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity, get_jwt
from datetime import timedelta

app = Flask(__name__)
CORS(app)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)

# ------------------- Config -------------------
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Sowmya21234'
app.config['MYSQL_DB'] = 'todoapp'
app.config['MYSQL_HOST'] = 'localhost'
app.config['JWT_SECRET_KEY'] = 'myapp123'

mysql = MySQL(app)

# ------------------- User APIs -------------------
@app.route("/userregister", methods=["POST"])
def user_register():
    data = request.json
    username = data.get('username')
    emailid = data.get('emailid')
    password = data.get('password')

    if not username or not emailid or not password:
        return jsonify({"error": "Missing credentials"}), 400

    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM users WHERE emailid = %s", (emailid,))
    if cur.fetchone():
        return jsonify({"error": "User already exists"}), 409

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    cur.execute("INSERT INTO users (username, emailid, password) VALUES (%s, %s, %s)",
                (username, emailid, hashed_password))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "User registered successfully"}), 201


@app.route('/userlogin', methods=['POST'])
def user_login():
    data = request.get_json()
    email = data.get('emailid')
    password = data.get('password')

    cur = mysql.connection.cursor()
    cur.execute("SELECT userid, username, password FROM users WHERE emailid = %s", (email,))
    user = cur.fetchone()
    cur.close()

    if user and bcrypt.check_password_hash(user[2], password):
        access_token = create_access_token(identity=str(user[0]), expires_delta=timedelta(hours=1))
        return jsonify({'message': 'Login successful', 'token': access_token})
    else:
        return jsonify({'error': 'Invalid email or password'}), 401


@app.route("/profile", methods=["GET"])
@jwt_required()
def user_profile():
    current_user = get_jwt_identity()
    jwt_data = get_jwt()

    cur = mysql.connection.cursor()
    cur.execute("SELECT username FROM users WHERE userid = %s", (current_user,))
    row = cur.fetchone()
    cur.close()

    if not row:
        return jsonify({"error": "User not found"}), 404

    return jsonify({
        "userid": current_user,
        "Jwt": jwt_data,
        "username": row[0]
    })


# ------------------- Product APIs -------------------
@app.route("/addproduct", methods=["POST"])
@jwt_required()
def addproduct():
    data = request.json
    proname = data.get('proname')
    prodesc = data.get('prodesc')
    procategory = data.get('procategory')
    proprice = data.get('proprice')
    probrand = data.get('probrand')

    if not all([proname, prodesc, procategory, proprice, probrand]):
        return jsonify({"error": "Missing product details"}), 400

    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO products (proname, prodesc, procategory, proprice, probrand) VALUES (%s, %s, %s, %s, %s)",
                (proname, prodesc, procategory, proprice, probrand))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Product added successfully"}), 201


@app.route("/viewallproducts", methods=["GET"])
def view_all_products():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM products")
    rows = cur.fetchall()
    col_names = [desc[0] for desc in cur.description]
    cur.close()
    results = [dict(zip(col_names, row)) for row in rows]
    return jsonify(results)


@app.route("/viewproduct", methods=["GET"])
def get_product_by_category():
    category = request.args.get("category")
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM products WHERE LOWER(procategory) = LOWER(%s)", (category,))
    rows = cur.fetchall()
    col_name = [desc[0] for desc in cur.description]
    cur.close()
    results = [dict(zip(col_name, row)) for row in rows]
    return jsonify(results)


@app.route("/viewproductsort", methods=["GET"])
def get_product_sort():
    category = request.args.get("category")
    sort = request.args.get("sort", "proid")
    sort_order = "ASC"

    if sort.startswith("-"):
        sort_order = "DESC"
        sort = sort[1:]

    allowed_sort_columns = {"proid", "proname", "proprice", "probrand", "procategory"}
    if sort not in allowed_sort_columns:
        return jsonify({"error": "Invalid sort column"}), 400

    sql = "SELECT * FROM products WHERE 1=1"
    params = []

    if category:
        sql += " AND procategory=%s"
        params.append(category)

    sql += f" ORDER BY {sort} {sort_order}"

    cur = mysql.connection.cursor()
    cur.execute(sql, params)
    rows = cur.fetchall()
    col_name = [desc[0] for desc in cur.description]
    cur.close()
    results = [dict(zip(col_name, row)) for row in rows]
    return jsonify(results)


# ------------------- Order API -------------------
@app.route("/orderproduct", methods=["POST"])
@jwt_required()
def order_product():
    data = request.get_json()
    userid = get_jwt_identity()
    proid = data.get("proid")
    quantity = data.get("quantity")
    amount = data.get("amount")

    if not all([proid, quantity, amount]):
        return jsonify({"error": "Missing order details"}), 400

    total = float(amount) * int(quantity)

    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO ordertable (userid, proid, quantity, totalamount) VALUES (%s, %s, %s, %s)",
                (userid, proid, quantity, total))
    mysql.connection.commit()
    cur.close()

    return jsonify({"message": "Order placed successfully"}), 201


# ------------------- Main -------------------
if __name__ == "__main__":
    app.run(debug=True)
